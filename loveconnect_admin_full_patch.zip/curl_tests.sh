
#!/usr/bin/env bash
# CURL TESTS FOR ADMIN SMS LIMITS
# Set ENV: export API_HOST='http://localhost:3000' and export TOKEN='<admin_jwt>'
HOST="${API_HOST:-http://localhost:3000}"
TOKEN="${TOKEN:-}"

echo "1) Get profile limits (user)"
curl -s -H "Authorization: Bearer $TOKEN" "$HOST/api/profile/limits" | jq || true
echo
echo "2) List users (admin)"
curl -s -H "Authorization: Bearer $TOKEN" "$HOST/api/admin/users?page=1&limit=10" | jq || true
echo
echo "3) Set limit for a user (example)"
# replace USER_ID with actual user id
echo '{"userId":"USER_ID_HERE","limit":20}' | jq
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -d '{"userId":"USER_ID_HERE","limit":20}' "$HOST/api/admin/set-limit" | jq || true
echo
echo "4) Reset daily counter for user (example)"
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" "$HOST/api/admin/reset-daily/USER_ID_HERE" | jq || true
echo
echo "5) Grant SMS package (example)"
echo '{"userId":"USER_ID_HERE","qty":50}' | jq
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -d '{"userId":"USER_ID_HERE","qty":50}' "$HOST/api/admin/consume-package" | jq || true
echo
echo "Notes: set TOKEN and API_HOST environment variables before running."
